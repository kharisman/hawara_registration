<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Hash;
use Session;
use App\Models\User;

class HomeController extends Controller
{
    public function index()
    {
        $auth  = Auth::user();
        // return $auth ; 
        return view('home');
    }


}
