<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SettingController extends Controller
{
    //
    public function website(Request $request)
    {
        return view('home');
    }

    public function program_mitra(Request $request)
    {
        return view('home');
    }
}
