<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reseller;
use App\Models\ResellerPayment;

class ReportController extends Controller
{
    //
    public function pendaftaran_mitra(Request $request)
    {
        $resellers = Reseller::get();
        // return $resellers;
        return view('report.mitra.mitra',compact('resellers'));
    }

    public function transaksi_mitra(Request $request)
    {
        $trxs = ResellerPayment::orderBy("id","DESC")->with("reseller")->with('product')->get();
        return view('report.mitra.transaksi',compact('trxs'));
    }
}
